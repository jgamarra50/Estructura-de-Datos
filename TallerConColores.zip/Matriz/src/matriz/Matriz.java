/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package matriz;
import java.util.Random;
public class Matriz {

    public static void main(String[] args) {
        int array[][] = new int[6][6];
        Random random = new Random();
        System.out.println("\nPrimer Matriz:");
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[0].length; j++) {
                array[i][j] = random.nextInt(100);
                System.out.print(array[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println();
        System.out.println("\nPrimer Matriz con diagonal de 0:");
        int tmp = 0;
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[0].length; j++) {
                if (i == j) {
                    array[i][j] = 0;
                }
                System.out.print(array[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println("\nPrimer Matriz ultima columna id y edad en la esquina inferior:");
        array[0][array[0].length - 1] = 9;

        array[array.length - 1][0] = 19;

        System.out.println();
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[0].length; j++) {
                System.out.print(array[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println("\nSegunda Matriz:");
        int array2[][] = new int[4][6];
        Random random2 = new Random();

        for (int i = 0; i < array2.length; i++) {
            for (int j = 0; j < array2[0].length; j++) {
                array2[i][j] = random2.nextInt(100);
                System.out.print(array2[i][j] + "\t");
            }
            System.out.println();
        }
        for (int j = 0; j < array2[0].length; j++) {
            int temp = array2[1][j];
            array2[1][j] = array2[2][j];
            array2[2][j] = temp;
        }

        System.out.println("\nSegunda Matriz con Filas del Medio Intercambiadas:");
        for (int i = 0; i < array2.length; i++) {
            for (int j = 0; j < array2[0].length; j++) {
                System.out.print(array2[i][j] + "\t");
            }
            System.out.println();
        }
    }
}