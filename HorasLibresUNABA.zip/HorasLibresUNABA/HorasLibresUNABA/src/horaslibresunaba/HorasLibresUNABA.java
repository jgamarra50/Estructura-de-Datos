/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package horaslibresunaba;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.HashMap;

public class HorasLibresUNABA extends JFrame implements ActionListener {
    private JTextField campoNombre, campoHorasLibres, campoNuevoEvento, campoUsuario, campoContrasena, campoNuevoUsuario, campoNuevaContrasena;
    private JComboBox<String> comboEvento, comboCarrera;
    private JComboBox<Integer> comboSemestres;
    private JButton botonRegistrar, botonExportar, botonVerificar, botonAgregarEvento, botonLogin, botonCalcularPromedios, botonHorasLibres, botonRegistrarse, botonDarseDeBaja, botonModificarEvento, botonEliminarEvento;
    private JTextArea areaResultado;
    private GestorEventos gestorEventos;
    private GestorUsuarios gestorUsuarios;
    private int horasAcumuladas = 0;

    public HorasLibresUNABA() {
        setTitle("Registro de Horas Libres UNAB");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(135, 206, 235));

        gestorEventos = new GestorEventos();
        gestorUsuarios = new GestorUsuarios();

        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.addTab("Login", crearPanelLogin());
        tabbedPane.addTab("Registro de Horas", crearPanelRegistroHoras());
        tabbedPane.addTab("Eventos", crearPanelEventos());
        tabbedPane.addTab("Promedios", crearPanelPromedios());
        tabbedPane.addTab("Usuarios", crearPanelUsuarios());

        areaResultado = new JTextArea();
        areaResultado.setEditable(false);
        areaResultado.setBackground(new Color(255, 255, 204));
        JScrollPane scrollPane = new JScrollPane(areaResultado);

        setLayout(new BorderLayout());
        add(tabbedPane, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);

        setVisible(true);
    }

    private JPanel crearPanelLogin() {
        JPanel panelLogin = new JPanel(new GridBagLayout());
        panelLogin.setBackground(new Color(135, 206, 235));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelLogin.add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1;
        campoUsuario = new JTextField(15);
        panelLogin.add(campoUsuario, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelLogin.add(new JLabel("Contraseña:"), gbc);
        gbc.gridx = 1;
        campoContrasena = new JPasswordField(15);
        panelLogin.add(campoContrasena, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        botonLogin = new JButton("Login");
        botonLogin.addActionListener(this);
        panelLogin.add(botonLogin, gbc);
        return panelLogin;
    }

    private JPanel crearPanelRegistroHoras() {
        JPanel panelRegistro = new JPanel(new GridBagLayout());
        panelRegistro.setBackground(new Color(135, 206, 235));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelRegistro.add(new JLabel("Nombre del Estudiante:"), gbc);
        gbc.gridx = 1;
        campoNombre = new JTextField(15);
        panelRegistro.add(campoNombre, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelRegistro.add(new JLabel("Horas Libres:"), gbc);
        gbc.gridx = 1;
        campoHorasLibres = new JTextField(15);
        panelRegistro.add(campoHorasLibres, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        panelRegistro.add(new JLabel("Evento:"), gbc);
        gbc.gridx = 1;
        comboEvento = new JComboBox<>();
        panelRegistro.add(comboEvento, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        panelRegistro.add(new JLabel("Nuevo Evento:"), gbc);
        gbc.gridx = 1;
        campoNuevoEvento = new JTextField(15);
        panelRegistro.add(campoNuevoEvento, gbc);
        gbc.gridx = 0;
        gbc.gridy = 4;
        panelRegistro.add(new JLabel("Carrera:"), gbc);
        gbc.gridx = 1;
        comboCarrera = new JComboBox<>(new String[]{"Ing. de Sistemas", "Derecho", "Biomedica", "Ing. Industrial", "Otra"});
        panelRegistro.add(comboCarrera, gbc);
        gbc.gridx = 0;
        gbc.gridy = 5;
        panelRegistro.add(new JLabel("Semestres:"), gbc);
        gbc.gridx = 1;
        comboSemestres = new JComboBox<>(new Integer[]{1, 2, 3, 4, 5, 6, 7, 8, 9});
        panelRegistro.add(comboSemestres, gbc);
        gbc.gridx = 0;
        gbc.gridy = 6;
        botonRegistrar = new JButton("Registrar");
        botonRegistrar.addActionListener(this);
        panelRegistro.add(botonRegistrar, gbc);
        return panelRegistro;
    }

    private JPanel crearPanelEventos() {
        JPanel panelEventos = new JPanel(new GridBagLayout());
        panelEventos.setBackground(new Color(135, 206, 235));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelEventos.add(new JLabel("Evento (existente):"), gbc);
        gbc.gridx = 1;
        comboEvento = new JComboBox<>();
        panelEventos.add(comboEvento, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelEventos.add(new JLabel("Nuevo Evento:"), gbc);
        gbc.gridx = 1;
        campoNuevoEvento = new JTextField(15);
        panelEventos.add(campoNuevoEvento, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        botonAgregarEvento = new JButton("Agregar Evento");
        botonAgregarEvento.addActionListener(this);
        panelEventos.add(botonAgregarEvento, gbc);
        gbc.gridx = 1;
        botonModificarEvento = new JButton("Modificar Evento");
        botonModificarEvento.addActionListener(this);
        panelEventos.add(botonModificarEvento, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        botonEliminarEvento = new JButton("Eliminar Evento");
        botonEliminarEvento.addActionListener(this);
        panelEventos.add(botonEliminarEvento, gbc);
        return panelEventos;
    }

    private JPanel crearPanelPromedios() {
        JPanel panelPromedios = new JPanel(new GridBagLayout());
        panelPromedios.setBackground(new Color(135, 206, 235));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        botonCalcularPromedios = new JButton("Calcular Promedios");
        botonCalcularPromedios.addActionListener(this);
        panelPromedios.add(botonCalcularPromedios, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        botonHorasLibres = new JButton("Horas Libres Restantes");
        botonHorasLibres.addActionListener(this);
        panelPromedios.add(botonHorasLibres, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        botonVerificar = new JButton("Verificar Graduación");
        botonVerificar.addActionListener(this);
        panelPromedios.add(botonVerificar, gbc);
        return panelPromedios;
    }

    private JPanel crearPanelUsuarios() {
        JPanel panelUsuarios = new JPanel(new GridBagLayout());
        panelUsuarios.setBackground(new Color(135, 206, 235));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelUsuarios.add(new JLabel("Nuevo Usuario:"), gbc);
        gbc.gridx = 1;
        campoNuevoUsuario = new JTextField(15);
        panelUsuarios.add(campoNuevoUsuario, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelUsuarios.add(new JLabel("Nueva Contraseña:"), gbc);
        gbc.gridx = 1;
        campoNuevaContrasena = new JPasswordField(15);
        panelUsuarios.add(campoNuevaContrasena, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        botonRegistrarse = new JButton("Registrarse");
        botonRegistrarse.addActionListener(this);
        panelUsuarios.add(botonRegistrarse, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        botonDarseDeBaja = new JButton("Darse de Baja");
        botonDarseDeBaja.addActionListener(this);
        panelUsuarios.add(botonDarseDeBaja, gbc);
        return panelUsuarios;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        switch (comando) {
            case "Registrar":
                registrarHorasLibres();
                break;
            case "Agregar Evento":
                agregarEvento();
                break;
            case "Modificar Evento":
                modificarEvento();
                break;
            case "Eliminar Evento":
                eliminarEvento();
                break;
            case "Login":
                login();
                break;
            case "Registrarse":
                registrarse();
                break;
            case "Darse de Baja":
                darseDeBaja();
                break;
            case "Calcular Promedios":
                calcularPromedios();
                break;
            case "Horas Libres Restantes":
                mostrarHorasLibresRestantes();
                break;
            case "Verificar Graduación":
                verificarGraduacion();
                break;
            default:
                break;
        }
    }

    private void registrarHorasLibres() {
        String nombre = campoNombre.getText();
        int horasLibres = Integer.parseInt(campoHorasLibres.getText());
        String evento = (String) comboEvento.getSelectedItem();
        gestorEventos.registrarEvento(nombre, evento, horasLibres);
        areaResultado.append("Horas registradas para " + nombre + " en el evento " + evento + ": " + horasLibres + " horas.\n");
    }

    private void agregarEvento() {
        String nuevoEvento = campoNuevoEvento.getText();
        gestorEventos.agregarEvento(nuevoEvento);
        comboEvento.addItem(nuevoEvento);
        areaResultado.append("Nuevo evento agregado: " + nuevoEvento + "\n");
    }

    private void modificarEvento() {
        String eventoSeleccionado = (String) comboEvento.getSelectedItem();
        String nuevoNombre = campoNuevoEvento.getText();
        gestorEventos.modificarEvento(eventoSeleccionado, nuevoNombre);
        comboEvento.removeItem(eventoSeleccionado);
        comboEvento.addItem(nuevoNombre);
        areaResultado.append("Evento modificado: " + eventoSeleccionado + " a " + nuevoNombre + "\n");
    }

    private void eliminarEvento() {
        String eventoSeleccionado = (String) comboEvento.getSelectedItem();
        gestorEventos.eliminarEvento(eventoSeleccionado);
        comboEvento.removeItem(eventoSeleccionado);
        areaResultado.append("Evento eliminado: " + eventoSeleccionado + "\n");
    }

    private void login() {
        String usuario = campoUsuario.getText();
        String contrasena = new String(((JPasswordField) campoContrasena).getPassword());
        if (gestorUsuarios.login(usuario, contrasena)) {
            areaResultado.append("Login exitoso. Bienvenido " + usuario + "\n");
        } else {
            areaResultado.append("Login fallido. Usuario o contraseña incorrecta.\n");
        }
    }

    private void registrarse() {
        String nuevoUsuario = campoNuevoUsuario.getText();
        String nuevaContrasena = new String(((JPasswordField) campoNuevaContrasena).getPassword());
        gestorUsuarios.registrarUsuario(nuevoUsuario, nuevaContrasena);
        areaResultado.append("Usuario registrado: " + nuevoUsuario + "\n");
    }

    private void darseDeBaja() {
        String usuario = campoUsuario.getText();
        gestorUsuarios.darseDeBaja(usuario);
        areaResultado.append("Usuario dado de baja: " + usuario + "\n");
    }

    private void calcularPromedios() {
        double promedio = gestorEventos.calcularPromedioHoras();
        areaResultado.append("Promedio de horas libres: " + promedio + "\n");
    }

    private void mostrarHorasLibresRestantes() {
        int horasRestantes = gestorEventos.calcularHorasRestantes();
        areaResultado.append("Horas libres restantes: " + horasRestantes + "\n");
    }

    private void verificarGraduacion() {
        boolean puedeGraduarse = gestorEventos.verificarGraduacion();
        if (puedeGraduarse) {
            areaResultado.append("El estudiante cumple con las horas libres necesarias para graduarse.\n");
        } else {
            areaResultado.append("El estudiante no cumple con las horas libres necesarias para graduarse.\n");
        }
    }

    public static void main(String[] args) {
        new HorasLibresUNABA();
    }
}

class GestorEventos {
    private HashMap<String, Integer> eventos;

    public GestorEventos() {
        eventos = new HashMap<>();
    }

    public void registrarEvento(String nombre, String evento, int horasLibres) {
        eventos.put(nombre + "-" + evento, horasLibres);
    }

    public void agregarEvento(String evento) {
        if (!eventos.containsKey(evento)) {
            eventos.put(evento, 0);
        }
    }

    public void modificarEvento(String eventoViejo, String eventoNuevo) {
        if (eventos.containsKey(eventoViejo)) {
            int horas = eventos.remove(eventoViejo);
            eventos.put(eventoNuevo, horas);
        }
    }

    public void eliminarEvento(String evento) {
        eventos.remove(evento);
    }

    public double calcularPromedioHoras() {
        if (eventos.size() == 0) return 0;
        int totalHoras = eventos.values().stream().mapToInt(Integer::intValue).sum();
        return (double) totalHoras / eventos.size();
    }

    public int calcularHorasRestantes() {
        return eventos.values().stream().mapToInt(Integer::intValue).sum();
    }

    public boolean verificarGraduacion() {
        return calcularHorasRestantes() >= 160;
    }
}

class GestorUsuarios {
    private HashMap<String, String> usuarios;

    public GestorUsuarios() {
        usuarios = new HashMap<>();
    }

    public void registrarUsuario(String usuario, String contrasena) {
        usuarios.put(usuario, contrasena);
    }

    public boolean login(String usuario, String contrasena) {
        return usuarios.containsKey(usuario) && usuarios.get(usuario).equals(contrasena);
    }

    public void darseDeBaja(String usuario) {
        usuarios.remove(usuario);
    }
}


